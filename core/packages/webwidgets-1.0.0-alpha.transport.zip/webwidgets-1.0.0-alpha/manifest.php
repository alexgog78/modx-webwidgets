<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for WebWidgets.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
WebWidgets
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'WebWidgets
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'dd87d5b6ec19a099329a84c5355e3121',
      'native_key' => 'webwidgets',
      'filename' => 'modNamespace/a828c639d28571ca2e618d022f958681.vehicle',
      'namespace' => 'webwidgets',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '0ade01d46c4f52731f5ece049254a698',
      'native_key' => '0ade01d46c4f52731f5ece049254a698',
      'filename' => 'xPDOFileVehicle/7b1abc55ecbd5358bf650ff8767005c9.vehicle',
      'namespace' => 'webwidgets',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'eefc776cf1a7eb279c21719604afd514',
      'native_key' => 'eefc776cf1a7eb279c21719604afd514',
      'filename' => 'xPDOFileVehicle/7b44c2d6d35bbaaf7baefc7e1bbdd0eb.vehicle',
      'namespace' => 'webwidgets',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '5a997ba92e8bbe3db347e7c8f6e60888',
      'native_key' => 'webwidgets',
      'filename' => 'modMenu/4e668952b43e3d977a36344c94b59856.vehicle',
      'namespace' => 'webwidgets',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'dbb12950dab440225d9698ed44da17f9',
      'native_key' => 1,
      'filename' => 'modCategory/b3b57d0f328bec849158b6f95d06aaa6.vehicle',
      'namespace' => 'webwidgets',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '310f2939e4359fbe0e5a3e7b036af3bf',
      'native_key' => '310f2939e4359fbe0e5a3e7b036af3bf',
      'filename' => 'xPDOScriptVehicle/72c3189d01af9682f2b4cc513009ac2c.vehicle',
      'namespace' => 'webwidgets',
    ),
  ),
);