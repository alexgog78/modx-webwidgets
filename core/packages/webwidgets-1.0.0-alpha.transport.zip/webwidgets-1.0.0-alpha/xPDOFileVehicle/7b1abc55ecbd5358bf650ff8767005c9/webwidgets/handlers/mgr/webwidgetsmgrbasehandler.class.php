<?php

class WebWidgetsMgrBaseHandler extends AbstractMgrHandler
{
    /**
     * @param modManagerController $controller
     */
    public function loadAssets(modManagerController $controller)
    {
        parent::loadAssets($controller);
    }
}
