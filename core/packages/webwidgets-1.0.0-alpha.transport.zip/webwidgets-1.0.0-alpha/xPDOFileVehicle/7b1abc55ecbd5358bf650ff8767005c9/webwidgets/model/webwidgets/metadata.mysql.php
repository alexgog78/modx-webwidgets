<?php

$xpdo_meta_map = [
    'AbstractSimpleObject' => [
        0 => 'webwidgetsChunk',
    ],
];
