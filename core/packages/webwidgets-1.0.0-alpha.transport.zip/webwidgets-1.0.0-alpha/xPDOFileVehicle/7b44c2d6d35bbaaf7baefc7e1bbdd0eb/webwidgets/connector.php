<?php

define('PKG_NAME', 'WebWidgets');
define('PKG_NAME_LOWER', 'webwidgets');

require_once dirname(dirname(__FILE__)) . '/abstractmodule/connector.php';
