<?php

$prefix = 'webwidgets.';

$_lang[$prefix . 'title.creating'] = 'Создаем: [[+record]]';
$_lang[$prefix . 'title.editing'] = 'Редактируем: [[+record]]';
$_lang[$prefix . 'controls.view'] = 'Просмотр';
$_lang[$prefix . 'controls.return'] = 'Назад';
$_lang[$prefix . 'controls.upload'] = 'Загрузить';
$_lang[$prefix . 'controls.source'] = 'Источник файлов';

$_lang[$prefix . 'section.chunks'] = 'Дополнительные виджеты и meta-теги для сайта';
$_lang[$prefix . 'section.chunks.management'] = 'Управляйте вашими дополнительными виджетами здесь. Вы можете изменять их двойным щелчком по необходимому полю или щелчком правой кнопки мыши по необходимому ряду.';
$_lang[$prefix . 'section.chunk'] = 'Дополнительный виджет';
$_lang[$prefix . 'section.chunk.management'] = 'Редактирование данных виджета.';
