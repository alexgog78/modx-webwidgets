<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for WebWidgets.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
WebWidgets
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'WebWidgets
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3eae35eb050e7e1ffa3866b315fa3db1',
      'native_key' => 'webwidgets',
      'filename' => 'modNamespace/efc546fcb8a1512dd7e18ad4c52e4b81.vehicle',
      'namespace' => 'webwidgets',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'd7f008025d475b72ec1dd175451f00df',
      'native_key' => 'd7f008025d475b72ec1dd175451f00df',
      'filename' => 'xPDOFileVehicle/9b84dd7d49c35a0913c17a90b6b571a5.vehicle',
      'namespace' => 'webwidgets',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'f418e151f48c1f7d27d0ba54a7c0f638',
      'native_key' => 'f418e151f48c1f7d27d0ba54a7c0f638',
      'filename' => 'xPDOFileVehicle/0a73bae48f20bcf93bb5458364b4688d.vehicle',
      'namespace' => 'webwidgets',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '800183919308ce96a0b89b4a9eb38854',
      'native_key' => 'webwidgets',
      'filename' => 'modMenu/95b733bf89c8d1385884ce7e320e0cb1.vehicle',
      'namespace' => 'webwidgets',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '006f44ca80cbf0d43ad0ea02ee6c9f4e',
      'native_key' => 1,
      'filename' => 'modCategory/b18c02c23ea46dac9485a39b2a926f2d.vehicle',
      'namespace' => 'webwidgets',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'e596466a7998a32dc1463afab0b5735d',
      'native_key' => 'e596466a7998a32dc1463afab0b5735d',
      'filename' => 'xPDOScriptVehicle/17ba4340d1d8621fde4a54be0eeb4051.vehicle',
      'namespace' => 'webwidgets',
    ),
  ),
);