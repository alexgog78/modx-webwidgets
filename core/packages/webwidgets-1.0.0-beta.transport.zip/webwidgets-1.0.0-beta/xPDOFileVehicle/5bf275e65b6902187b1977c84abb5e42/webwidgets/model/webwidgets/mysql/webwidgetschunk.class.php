<?php

require_once(dirname(__DIR__) . '/webwidgetschunk.class.php');

class WebWidgetsChunk_mysql extends WebWidgetsChunk
{
}
