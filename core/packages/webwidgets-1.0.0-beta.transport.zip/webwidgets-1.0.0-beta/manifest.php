<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for WebWidgets.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
WebWidgets
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'WebWidgets
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f8bf4ce0ca91e5992a6c34123f7ea027',
      'native_key' => 'webwidgets',
      'filename' => 'modNamespace/10094543f57c0a6a949f721e84fb7148.vehicle',
      'namespace' => 'webwidgets',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'c4bdd6dab87fd7849f7cb31a867e9511',
      'native_key' => 'c4bdd6dab87fd7849f7cb31a867e9511',
      'filename' => 'xPDOFileVehicle/5bf275e65b6902187b1977c84abb5e42.vehicle',
      'namespace' => 'webwidgets',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '62d702b451cadca5458951c5904bd78f',
      'native_key' => '62d702b451cadca5458951c5904bd78f',
      'filename' => 'xPDOFileVehicle/c95c93d2696eea2f8b34433dc209f28b.vehicle',
      'namespace' => 'webwidgets',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '1bc185620e8a75f4189d512ece9cc9a0',
      'native_key' => 'webwidgets',
      'filename' => 'modMenu/8d57f9f38be111f9b0292fee01e5e80b.vehicle',
      'namespace' => 'webwidgets',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3039f750fa608e561884e374f7a9366a',
      'native_key' => 1,
      'filename' => 'modCategory/e83e0843acf78e6fca435d1e000c0ada.vehicle',
      'namespace' => 'webwidgets',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '96995f5ab604c7000bf6567e600bab6d',
      'native_key' => '96995f5ab604c7000bf6567e600bab6d',
      'filename' => 'xPDOScriptVehicle/30d05d7fde4904fa03da9800d52cbf58.vehicle',
      'namespace' => 'webwidgets',
    ),
  ),
);